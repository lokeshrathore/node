var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);

app.get('/', function(req, res){
  res.sendFile(__dirname + '/index.html');
});


app.get('/jquerylib', function(req, res){
  res.sendFile(__dirname + '/public/jquery-1.11.1.js');
});


app.get('/socketlib', function(req, res){
  res.sendFile(__dirname + '/public/socket.io-1.2.0.js');
});

app.get('/admin', function(req, res){
  res.sendFile(__dirname + '/admin.html');
});

app.get('/userPage', function(req, res){
  res.sendFile(__dirname + '/userPage.html');
});

app.get('/userPage1', function(req, res){
  res.sendFile(__dirname + '/userPage1.html');
});

io.on('connection', function(socket){
  socket.on('chat message', function(msg){
    io.emit('msg_send_client', msg);
  });
});

http.listen(3000, function(){
  console.log('listening on *:3000');
});
