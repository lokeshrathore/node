var myApp = angular.module('myApp', []);

myApp.service('authService', [function(){
	
}])
.controller("AdminController", ["$scope", '$timeout',
	function($scope, $timeout) {
	  	console.log("adminContrller Initialized");
	  	var socket = io();
      	
      	$scope.user1 = { userid : 'user1', msg : ''};
      	$scope.user2 = { userid : 'user2', msg : ''};


      	$scope.sendMessageToUser = function(userObj){
	        if(userObj.msg && userObj.msg.trim()!=''){
	            socket.emit('chat message', userObj);
	            userObj.msg = '';
	        }
      	}
 	 	
	      // socket.on('msg_send_client', function(msg){
	      //   $('#messages').append($('<li>').text(msg));
	      // });
	}
])
.controller("User1Controller", ["$scope", '$timeout',
	function($scope, $timeout) {
		$scope.messages = [];
	  	console.log("user1Contrller Initialized");
	  	var socket = io();
      	var userid  = "user1";
      	socket.on('msg_send_client', function(msgObj){
	        if(msgObj.userid === userid){
	        	$scope.messages.push(msgObj.msg);
       			$scope.$digest();
	        	//$timeout(function() {$scope.messages.push(msgObj.msg);},0);
	        }
      	});
	}
]).controller("User2Controller", ["$scope", '$timeout',
	function($scope, $timeout) {
	  	$scope.messages = [];
	  	console.log("user2Contrller Initialized");
	  	var socket = io();
      	var userid  = "user2";
      	socket.on('msg_send_client', function(msgObj){
	        if(msgObj.userid === userid){
	        	//$timeout(function() {$scope.messages.push(msgObj.msg);}, 0);
	        	$scope.messages.push(msgObj.msg);
       			$scope.$digest();
	        }
      	});
	}
]);