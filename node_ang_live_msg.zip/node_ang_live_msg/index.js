var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);

// currentaly not used
app.get('/', function(req, res){
  res.sendFile(__dirname + '/index.html');
});

// load js files
app.get('/jquerylib', function(req, res){
  res.sendFile(__dirname + '/public/jquery-1.11.1.js');
});
app.get('/angulrlib', function(req, res){
  res.sendFile(__dirname + '/public/angular.min.js');
});
app.get('/scripts', function(req, res){
  res.sendFile(__dirname + '/public/scripts.js');
});
app.get('/socketlib', function(req, res){
  res.sendFile(__dirname + '/public/socket.io-1.2.0.js');
});
// End load js files

app.get('/admin', function(req, res){
  res.sendFile(__dirname + '/admin.html');
});

app.get('/userPage1', function(req, res){
  res.sendFile(__dirname + '/userPage1.html');
});

app.get('/userPage2', function(req, res){
  res.sendFile(__dirname + '/userPage2.html');
});

io.on('connection', function(socket){
  socket.on('chat message', function(msg){
    io.emit('msg_send_client', msg);
  });
});

http.listen(3000, function(){
  console.log('listening on *:3000');
});
