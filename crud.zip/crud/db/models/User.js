var Sequelize = require('sequelize'),
config = require(__dirname + '/../dbconfig'),
sequelize = new Sequelize(config.database, config.username, config.password, {host: config.host, logging: false});

var User = sequelize.define('user', {
id: {
	type: Sequelize.INTEGER,
	allowNull: false,
	primaryKey: true,
	autoIncrement: true,
	defaultValue: ''  
},
first_name: {
	type: Sequelize.STRING,
	allowNull: false,
	defaultValue: ''  
},
last_name: {
	type: Sequelize.STRING,
	allowNull: false,
	defaultValue: ''  
},
email: {
	type: Sequelize.STRING,
	allowNull: false,
	defaultValue: ''  
},
password: {
	type: Sequelize.STRING,
	allowNull: false,
	defaultValue: ''  
}
}, {freezeTableName: true,  tablename:'user', timestamps: false });

module.exports = { User: User };