module.exports = {
    username: process.env.SEQ_USER || "root",
    password: process.env.SEQ_PW || '',
    //password: process.env.SEQ_PW || 'tvadmin1',
    database: process.env.SEQ_DB || 'crud',
    host: process.env.SEQ_HOST || 'localhost',
    //host: process.env.SEQ_HOST || '204.93.197.251',
    pool: {
        maxConnections: process.env.SEQ_POOL_MAX || 5,
        maxIdleTime: process.env.SEQ_POOL_IDLE || 3000
    }
}