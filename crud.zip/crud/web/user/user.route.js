var fs = require('node-fs');
// node-fs is used for image uploading.
var Sequelize = require('sequelize');
//sequilize is require for using channel query.
var output = rootRequire('web/helper/pagehelper.js');
//pagehelper function is require for specify data json/view
var users = rootRequire('db/models/Users');
//Users model function is used for Users table.
var groups = rootRequire('db/models/Groups');
//Group model function is used for Groups table.
var roles = rootRequire('db/models/Roles');
//Roles model function is used for Roles table.
var user_roles = rootRequire('db/models/User_role');
//User_role model function is used for User_role table.
var user_groups = rootRequire('db/models/Group_users');
//Group_users model function is used for Group_users table.
var group_roles = rootRequire('db/models/Group_users');
//Group_users model function is used for Group_users table.
var city = rootRequire('db/models/City');
//City model function is used for City table.
var state = rootRequire('db/models/State');
//State model function is used for State table.
var country = rootRequire('db/models/Country');
//Country model function is used for Country table.
var departments = rootRequire('db/models/Departments');
//Departments model function is used for Departments table.
var functions = rootRequire('db/models/Functions');
//Functions model function is used for Functions table.
var user_functions = rootRequire('db/models/User_functions');
//User_functions model function is used for User_functions table.
var email = require("mailer");
//mailer is used to send mail.
var nodemailer = require("nodemailer");
//nodemailer is used for send mail.
var smtpTransport = require('nodemailer-smtp-transport');
//nodemailer-smtp-transport is used for send mail.

/*
	index function is used for show user list
*/
exports.index = function(req, res) {

    var chainer = new Sequelize.Utils.QueryChainer
    var currentUserId = req.session.user_id;
    chainer.add(departments.Departments, 'findAll')
    chainer.runSerially().done(function(err, data, project) {

        users.Users.findAll({
            where: ["created_by > 0 AND status != 2 AND id !=".concat(currentUserId)],
            order: 'id DESC'
        }).on('success', function(data1) {

            if (data1) {

                output.render(req, res, 'user/list-users', {
                    display_name: req.session.display_name,
                    picture: req.session.picture,
                    email_address: req.session.email_address,
                    title: 'User',
                    data: data1,
                    department: data[0],
                });
            }

        })
    });
}

/*
	signup function is used for registration of external user.
*/
exports.signup = function(req, res) {

    users.Users.find({
        where: {
            email_address: req.body.email_address
        }
    }).on('success', function(emailExist) {
        if (emailExist) {
            res.send({
                "Error": "Email Id already exist ."
            });
        }
    });
   
    //var pwd = Math.floor((Math.random() * 999999) + 100000);
    if (!req.files.picture.name) {

        var user_signup = users.Users.build({
            first_name: req.body.first_name,
            last_name: req.body.last_name,
            display_name: req.body.display_name,
            country : (req.body.country_name == '') ? null : req.body.country_name,
		    state : (req.body.state_name == '') ? null : req.body.state_name,
		    city : (req.body.city_name == '') ? null : req.body.city_name,
            street: req.body.street,
            email_address: req.body.email_address,
            postal_code: req.body.postal_code,
            phone: req.body.phone,
            company: req.body.company,
            password: '123456',//Math.floor((Math.random() * 999999) + 100000),
            status: 2,
            is_internal: 0,
            created_on: Date()

        })

        user_signup.save().complete(function(err) {
            if ( !! err) {
            	
                throw (err)
                // res.send(err);
                res.send({
                    'Error': "User not registered , Please enter proper details."
                });
            } else {

                res.send({
                    'message': "Registration successful!!!Account activation information will be sent to your registered email address."
                });

            }
        })
    } else {

        var tmp_path = req.files.picture.path;
        var base = process.env.PWD;
        var time = new Date().getTime();
        var target_path = base + '/web/public/user_images/' + time + req.files.picture.name;

        // move the file from the temporary location to the intended location
        fs.rename(tmp_path, target_path, function(err) {
            if (err)
                throw err;
            // delete the temporary file, so that the explicitly set temporary upload dir does not get filled with unwanted files
            fs.unlink(tmp_path, function() {
                if (err)
                    throw err;
                // res.send('File uploaded to: ' + target_path + ' - ' + req.files.picture.size + ' bytes');
                var user_signup = users.Users.build({
                    first_name: req.body.first_name,
                    last_name: req.body.last_name,
                    display_name: req.body.display_name,
                    country : (req.body.country_name == '') ? null : req.body.country_name,
		            state : (req.body.state_name == '') ? null : req.body.state_name,
		            city : (req.body.city_name == '') ? null : req.body.city_name,
                    street: req.body.street,
                    postal_code: req.body.postal_code,
                    email_address: req.body.email_address,
                    phone: req.body.phone,
                    company: req.body.company,
                    password: '123456',//Math.floor((Math.random() * 999999) + 100000),
                    picture: time + req.files.picture.name,
                    status: 2,
                    is_internal: 0,
                    created_on: Date()
                })

                user_signup.save().complete(function(err) {
                    if ( !! err) {

                        res.send({
                            'Error': "User not registered , Please enter proper details."
                        });
                        // res.send(err);
                    } else {

                        res.send({
                            'message': "Registration successful!!!Account activation information will be sent to your registered email address "
                        });

                    }
                })
            });
        });

    }
};


/*
	this is using for updating the user profile !
*/
exports.userUpdate = function(req, res) {
    try {
        var user_id = req.body.user_id;

        user_roles.User_role.destroy({
            where: {
                user_id: req.body.user_id
            }
            /* where criteria */
        }).success(function(affectedRows) {

        });

        user_groups.Group_users.destroy({
            where: {
                user_id: user_id
            }
            /* where criteria */
        }).success(function(affectedRows) {

        });
        
        user_functions.User_functions.destroy({
            where: {
                user_id: user_id
            }
        }).success(function(affectedRows) {

        });

        if (typeof req.body.role_ids != 'undefined') {

            for (var y in req.body.role_ids) {
                var user_role = user_roles.User_role.build({
                    user_id: req.body.user_id,
                    role_id: req.body.role_ids[y],
                    created_by: req.session.user_id
                });

                user_role.save().complete(function(err) {
                    if ( !! err) {
                        throw (err)
                        // res.send(err);
                    } else {

                    }
                });

            }
        }

        if (typeof req.body.group_ids != 'undefined') {

            for (var x in req.body.group_ids) {

                var user_group_details = user_groups.Group_users.build({
                    user_id: user_id,
                    group_id: req.body.group_ids[x],
                    created_by: req.session.user_id
                });

                user_group_details.save().complete(function(err) {
                    if ( !! err) {
                        throw (err)
                        // res.send(err);
                    } else {

                    }

                });

            }
        }
        
        if (typeof req.body.function_ids != 'undefined') {

            for (var x in req.body.function_ids) {

                var user_function_update = user_functions.User_functions.build({
                    user_id: user_id,
                    function_id: req.body.function_ids[x],
                    created_by: req.session.user_id
                });

                user_function_update.save().complete(function(err) {
                    if ( !! err) {
                        throw (err)
                        // res.send(err);
                    } else {

                    }

                });

            }
        }
         
        if (!req.files.profile_pic.name) {
            users.Users.find({
                where: {
                    id: req.body.user_id
                }
            }).on('success', function(user_exist) {
                if (user_exist) {

                    user_exist.updateAttributes({
                        first_name: req.body.first_name,
                        last_name: req.body.last_name,
                        display_name: req.body.display_name,
                        country : (req.body.country == '') ? null : req.body.country,
		                state : (req.body.state == '') ? null : req.body.state,
		                city : (req.body.city == '') ? null : req.body.city,
                        street: req.body.street,
                        postal_code: req.body.postal_code,
                        email_address: req.body.email_address,
                        phone: req.body.phone,
                        company: req.body.company_id,
                        status: req.body.status,
                        department_id: req.body.department_id,
                        is_internal: req.body.is_internal,
                        updated_on: Date(),
                        created_by:req.session.user_id,
                        
                    }).success(function() {

                        users.Users.find({
                            where: {
                                id: req.body.user_id
                            }
                        }).on('success', function(user_data) {

                            if (user_data['status'] == 1) {

                                transporter.sendMail({
                                    from: 'GlobalCMS <manraj.parmar@techvalens.com>',
                                    to: user_data['email_address'],
                                    subject: 'GlobalCMS Password ',
                                    text: "",
                                    html: "<b>Your Password Is:" + user_data['password'] + "</b>"
                                }, function(error, response) {
                                    //Email not sent
                                    if (error) {
                                        throw (err)
                                        /*
										 res.send({
										 'Error' : "Email Send Fail"
										 });*/

                                    }
                                    //email send sucessfully
                                    else {

                                        /*
										 res.send({
										 'message' : "Password has been sent on Email Id."
										 });*/

                                    }
                                });
                            }
                        });

                    });
                }
            });
        } else {
            var tmp_path = req.files.profile_pic.path;
            var base = process.env.PWD;
            var time = new Date().getTime();
            var target_path = base + '/web/public/user_images/' + time + req.files.profile_pic.name;

            // move the file from the temporary location to the intended location
            fs.rename(tmp_path, target_path, function(err) {
                if (err)
                    throw err;
                // delete the temporary file, so that the explicitly set temporary upload dir does not get filled with unwanted files
                fs.unlink(tmp_path, function() {
                    if (err)
                        throw err;


                    users.Users.find({
                        where: {
                            id: req.body.user_id
                        }
                    }).on('success', function(user_exist) {
                        if (user_exist) { // if the record exists in the db

                            user_exist.updateAttributes({
                                first_name: req.body.first_name,
                                last_name: req.body.last_name,
                                display_name: req.body.display_name,
                                country : (req.body.country == '') ? null : req.body.country,
		                        state : (req.body.state == '') ? null : req.body.state,
		                        city : (req.body.city == '') ? null : req.body.city,
                                street: req.body.street,
                                postal_code: req.body.postal_code,
                                email_address: req.body.email_address,
                                phone: req.body.phone,
                                company: req.body.company_id,
                                status: req.body.status,
                                picture: time + req.files.profile_pic.name,
                                department_id: req.body.department_id,
                                is_internal: req.body.is_internal,
                                updated_on: Date(),
                                created_by:req.session.user_id,

                            }).success(function() {
                                if (req.body.status == 1) {
                                    users.Users.find({
                                        where: {
                                            id: req.body.user_id
                                        }
                                    }).on('success', function(user_data) {

                                        transporter.sendMail({
                                            from: 'GlobalCMS <manraj.parmar@techvalens.com>',
                                            to: user_data['email_address'],
                                            subject: 'GlobalCMS Password ',
                                            text: "",
                                            html: "<b>Your Password Is:" + user_data['password'] + "</b>"
                                        }, function(error, response) {
                                            //Email not sent
                                            if (error) {
                                                throw (err)
                                                /*
												 res.send({
												 'Error' : "Email Send Fail"
												 });*/

                                            }
                                            //email send sucessfully
                                            else {

                                                /*
												 res.send({
												 'message' : "Password has been sent on Email Id."
												 });*/

                                            }
                                        });
                                    });
                                }
                                res.send({
                                    'message': "User updated successfully ."
                                });
                            });
                        }
                    });

                });
            });
        }
        res.send({
            'message': "User updated successfully."
        });

    } catch (e) {
        res.send("Exception");
    }
}

/*
	This is using for checking email id in database!
*/
exports.ajax_check_email_id_exist = function(req, res) {
    try {

        users.Users.find({
            where: {
                email_address: req.body.email_address
            }
        }).on('success', function(emailExist) {
            if (emailExist) {

                res.send({
                    "Error": "Email Id already exist."
                });
            } else {

                res.send({
                    "message": ""
                });
            }
        });
    } catch (ex) {
        res.send(ex);
    }
};

/*
	This is using for fetch state accoding to select country!
*/
exports.getStateAjax = function(req, res) {

    var c_id = req.body.c_id;

    state.State.findAll({
        where: {
            country_id: c_id
        }
    }).complete(function(err, data) {
        if ( !! err) {
            throw (err)
        } else {

            res.send(data);

        }
    })
}

/*
	This is using for show city according to select state!
*/
exports.getCityAjax = function(req, res) {

    var s_id = req.body.s_id;

    city.City.findAll({
        where: {
            state_id: s_id
        }
    }).complete(function(err, data) {
        if ( !! err) {
            throw (err)
        } else {

            res.send(data);

        }
    })
}

/*
	This is using for creating new user!
*/
exports.ajax_user_create = function(req, res) {

    users.Users.find({
        where: {
            email_address: req.body.email_address
        }
    }).on('success', function(emailExist) {
        if (emailExist) {
            res.send({
                "Error": "Email id already exist ."
            });
        }
    });

    var input = req.body;

    var tmp_path = req.files.profile_pic.path;

    var base = process.env.PWD;

    var file_name = req.files.profile_pic.name;
    var time = new Date().getTime();
    var target_path = base + '/web/public/user_images/' + time + file_name;

    if (req.files.profile_pic.name) {

        fs.rename(tmp_path, target_path, function(err) {
            if (err)
                throw err;
            // delete the temporary file, so that the explicitly set temporary upload dir does not get filled with unwanted files
            fs.unlink(tmp_path, function() {
                if (err)
                    throw err;
            });
        });

    } else {

		time = '';
		req.files.profile_pic.name = '';
	}
	// res.send('File uploaded to: ' + target_path + ' - ' + req.files.picture.size + ' bytes');
	
	
	var user = users.Users.build({
		first_name : req.body.first_name,
		last_name : req.body.last_name,
		display_name : req.body.display_name,
		country : (req.body.country == '') ? null : req.body.country,
		state : (req.body.state == '') ? null : req.body.state,
		city : (req.body.city == '') ? null : req.body.city,
		street : req.body.street,
		postal_code : req.body.postal_code,
		email_address : req.body.email_address,
		phone : req.body.phone,
		company : req.body.company_id,
		status : req.body.status,
		picture : time + req.files.profile_pic.name,
		department_id : (req.body.department_id == '') ? null : req.body.department_id,
		password : 123456,
		is_internal : req.body.is_internal,
		created_by:req.session.user_id,
		created_on:Date()
	});


    

    user.__factory = {
        autoIncrementField: 'id'
    };
    //user.id = '';

    user.save().complete(function(err) {
        if ( !! err) {
            throw (err)
            // res.send(err);
        } else {

            var text;

            for (var x in req.body.group_ids) {

                var user_group = user_groups.Group_users.build({
                    user_id: user.id,
                    group_id: req.body.group_ids[x],
                    created_by: req.session.user_id

                });

                user_group.save().complete(function(err) {
                    if ( !! err) {
                        throw (err)
                        // res.send(err);
                    } else {}

                });

            }

            for (var y in req.body.role_ids) {

                var user_role = user_roles.User_role.build({
                    user_id: user.id,
                    role_id: req.body.role_ids[y],
                    created_by: req.session.user_id
                });

                user_role.save().complete(function(err) {
                    if ( !! err) {
                        res.send({
                            "Error": "Please select country / state / city."
                        });
                        // res.send(err);
                    } else {}
                });

            }


            /*add functions*/
            for (var y in req.body.function_ids) {

                var user_function = user_functions.User_functions.build({
                    user_id: user.id,
                    function_id: req.body.function_ids[y],
                    created_by: req.session.user_id,
                    created_on: Date()
                });

                user_function.save().complete(function(err) {
                    if ( !! err) {
                        throw (err)
                        // res.send(err);
                    } else {}
                });

            }

            res.send({
                "message": "User added successfully."
            });

        };
    });

};

/*
	This is using for logout and destroy session!
*/
exports.logout = function(req, res) {

    req.session.destroy();
    res.header('Cache-Control', 'no-cache');
    res.redirect('/');
};

/*
	This is using for deleting user!
*/
exports.deleteUser = function(req, res) {

    users.Users.find(req.body.user_id).on('success', function(data) {
        if (data) {
            data.destroy().error(function(err) {
                res.send({
                    "error": "You can't delete this user because it uses further."
                });
            }).success(function() {
                users.Users.findAll().success(function(allusers) {

                    res.send({
                        "message": "User deleted successfully.",
                        "data": allusers
                    });
                });
            });
        } else {
            res.send({
                "message": "User not found."
            });
        }
    }).on('error', function(err) {
        res.send({
            "error": "User not found."
        });
    });

};

/*
	This is used for add,edit, and view user.
*/
exports.manageUser = function(req, res) {

    try {

        var user_id;
        var pagemode;
        var pagetitle;

        if (typeof req.params.id !== 'undefined') {

            user_id = req.params.id;

            if (req.route.path == "/view/user/:id") {

                pagemode = 'View';
                pagetitle = 'View-profile';

            } else {

                pagemode = 'Edit';
                pagetitle = 'Update-Profile';
            }

        } else {

            pagemode = 'Add';
            user_id = '';
            pagetitle = 'Add-User';
        }

        users.Users.find(user_id).complete(function(err, user) {
            if ( !! err) {
                throw (err)
            } else if (!user && user_id != '') {
                res.send({
                    'Error': "User not exist"
                });

            } else {

                if (user == null) {

                    user = {
                        id: '',
                        first_name: '',
                        last_name: '',
                        display_name: '',
                        country: '',
                        state: '',
                        city: '',
                        street: '',
                        email_address: '',
                        phone: '',
                        status: '',
                        picture: '',
                        department_name: '',
                        department_id: '',
                        company: '',
                        postal_code: ''

                    };

                }

                var chainer = new Sequelize.Utils.QueryChainer
                chainer.add(roles.Roles, 'findAll')
                chainer.add(groups.Groups, 'findAll')
                chainer.add(functions.Functions, 'findAll')

                chainer.runSerially().done(function(err, data, project) {

                    if ( !! err)
                        throw (err)

                    var chainer2 = new Sequelize.Utils.QueryChainer
                    chainer2.add(city.City, 'findAll')
                    chainer2.add(state.State, 'findAll')
                    chainer2.add(country.Country, 'findAll')
                    chainer2.add(departments.Departments, 'findAll')

                    chainer2.runSerially().done(function(err, users, project) {

                        if (users) {

                            var user_roles_details = user_roles.User_role.findAll({
                                where: {
                                    user_id: req.params.id,
                                }
                            }).on('success', function(user_roles_details) {

                                var user_group_details = user_groups.Group_users.findAll({
                                    where: {
                                        user_id: req.params.id,
                                    }
                                }).on('success', function(user_group_details) {

                                    var user_function = user_functions.User_functions.findAll({
                                        where: {
                                            user_id: req.params.id,
                                        }
                                    }).on('success', function(user_function) {

                                        var allroles = data[0];
                                        for (i = 0; i < allroles.length; i++) {
                                            var id = allroles[i].dataValues.id;
                                            var hasUser = false;
                                            for (i1 = 0; i1 < user_roles_details.length; i1++) {
                                                if (user_roles_details[i1].dataValues.role_id == allroles[i].dataValues.id) {
                                                    hasUser = true;
                                                    break;
                                                }
                                            }
                                            allroles[i].dataValues.selected = hasUser;
                                        }

                                        var alldepartment = users[3];
                                        for (i = 0; i < alldepartment.length; i++) {
                                            var id = alldepartment[i].dataValues.id;
                                            var hasDepartment = false;
                                            for (i1 = 0; i1 < user.length; i1++) {
                                                if (user[i1].dataValues.department_id == alldepartment[i].dataValues.id) {

                                                    hasDepartment = true;
                                                    break;
                                                }
                                            }
                                            alldepartment[i].dataValues.selected = hasDepartment;
                                        }

                                        var allgroups = data[1];
                                        for (i = 0; i < allgroups.length; i++) {
                                            var id = allgroups[i].dataValues.id;
                                            var hasGroup = false;
                                            for (i1 = 0; i1 < user_group_details.length; i1++) {
                                                if (user_group_details[i1].dataValues.group_id == allgroups[i].dataValues.id) {
                                                    hasGroup = true;
                                                    break;
                                                }
                                            }
                                            allgroups[i].dataValues.selected = hasGroup;
                                        }

                                        var allcity = users[0];
                                        for (i = 0; i < allcity.length; i++) {
                                            var id = allcity[i].dataValues.id;
                                            var hasCity = false;

                                            if (user.city == allcity[i].dataValues.id) {
                                                hasCity = true;

                                            }
                                            allcity[i].dataValues.selected = hasCity;
                                        }

                                        var allstate = users[1];
                                        for (i = 0; i < allstate.length; i++) {
                                            var id = allstate[i].dataValues.id;
                                            var hasState = false;

                                            if (user.state == allstate[i].dataValues.id) {
                                                hasState = true;

                                            }
                                            allstate[i].dataValues.selected = hasState;
                                        }

                                        var allcountry = users[2];
                                        for (i = 0; i < allcountry.length; i++) {
                                            var id = allcountry[i].dataValues.id;
                                            var hasState = false;

                                            if (user.country == allcountry[i].dataValues.id) {
                                                hasState = true;

                                            }
                                            allcountry[i].dataValues.selected = hasState;
                                        }

                                        var allfunctions = data[2];
                                        for (i = 0; i < allfunctions.length; i++) {
                                            var id = allfunctions[i].dataValues.id;
                                            var hasfunction = false;
                                            for (i1 = 0; i1 < user_function.length; i1++) {
                                                if (user_function[i1].dataValues.function_id == allfunctions[i].dataValues.id) {

                                                    hasfunction = true;
                                                    break;
                                                }
                                            }
                                            allfunctions[i].dataValues.selected = hasfunction;
                                        }

                                        var funcArray = [];
                                        for (i = 0; i < allfunctions.length; i++) {
                                            if (allfunctions[i].dataValues.parent_function == null || allfunctions[i].dataValues.parent_function == '') {
                                                for (i1 = 0; i1 < allfunctions.length; i1++) {
                                                    if (allfunctions[i1].dataValues.parent_function == allfunctions[i].dataValues.id) {
                                                        var parentFnName = allfunctions[i].function_name;
                                                        var chileFnName = allfunctions[i1].function_name;
                                                        allfunctions[i1].dummyName = parentFnName.concat(' (').concat(chileFnName).concat(')');
                                                        funcArray.push(allfunctions[i1]);
                                                    }
                                                }
                                            }
                                        }

                                        output.render(req, res, 'user/manage-user', {
                                            title: pagetitle,
                                            pagemode: pagemode,
                                            display_name: req.session.display_name,
                                            picture: req.session.picture,
                                            email_address: req.session.email_address,
                                            title: 'User',
                                            user: user,

                                            city: allcity,
                                            state: allstate,
                                            country: allcountry,
                                            department: users[3],
                                            company: users[4],
                                            roles: allroles,
                                            groups: allgroups,
                                            functions: funcArray

                                        });

                                    });

                                });

                            });

                        } else {
                            throw (err)
                        }

                    });
                });

            };

        });

    } catch (e) {
        throw (err)
    }

};