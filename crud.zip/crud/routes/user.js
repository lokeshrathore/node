//var session = require('./sessionHelper.js');
//var multipart = require('connect-multiparty');
//var multipartMiddleware = multipart();
//var testroutes = require('./test.route.js');
var userroutes = rootRequire('web/user/user.route.js');

exports.configureRoutes = function(app) {
	  app.get('/adduser', userroutes.manageUser);
      //app.get('/adduser', session.isValidSession,session.hasAccess("adduser"), userroutes.manageUser);
       /*app.get('/edit/user/:id', session.isValidSession,session.hasAccess("edituser"), userroutes.manageUser);
       app.get('/view/user/:id', session.isValidSession,session.hasAccess("viewuser"), userroutes.manageUser);
       
       app.post('/ajax_user_create', session.isValidSession,multipartMiddleware, userroutes.ajax_user_create);
       app.get('/users', session.isValidSession,session.hasAccess("user"), userroutes.index);
      
	   app.post('/singup', multipartMiddleware, userroutes.signup);
	   app.post('/getStateAjax', userroutes.getStateAjax);
	   app.post('/getCityAjax', userroutes.getCityAjax);
	   app.post('/userUpdate', session.isValidSession,multipartMiddleware, userroutes.userUpdate);  
	   app.post('/ajax_delete_user', session.isValidSession, userroutes.deleteUser);
	   app.post('/ajax_check_email_id_exist', multipartMiddleware, userroutes.ajax_check_email_id_exist);
	   */

}; 
